//OopisOS v2.5 PWA

const CACHE_NAME = 'oopisos-cache-v2.5';
const ASSETS_TO_CACHE = [
    './',
    './index.html',
    './terminal.css',
    './oopisos2_5.js',
    './editor2_5.js',
    './lexpar2_5.js',
    './commexec2_5.js',
    './adventure2_5.js',
    './marked.min.js',
    './fonts/vt323.ttf'
];

// Install event: cache all the core assets
self.addEventListener('install', event => {
    event.waitUntil(
        caches.open(CACHE_NAME)
            .then(cache => {
                console.log('Opened cache and caching core assets');
                return cache.addAll(ASSETS_TO_CACHE);
            })
    );
    void self.skipWaiting();
});

// Activate event: clean up old caches
self.addEventListener('activate', event => {
    event.waitUntil(
        caches.keys().then(cacheNames => {
            return Promise.all(
                cacheNames.map(cache => {
                    if (cache !== CACHE_NAME) {
                        console.log('Service Worker: clearing old cache');
                        return caches.delete(cache);
                    }
                })
            );
        })
    );
    void self.clients.claim();
});

// Fetch event: serve assets from cache first
self.addEventListener('fetch', event => {
    event.respondWith(
        caches.match(event.request)
            .then(response => {
                    // Cache hit - return response
                    if (response) {
                        return response;
                    }
                    // Not in cache - fetch from network
                    return fetch(event.request);
                }
            )
    );
});